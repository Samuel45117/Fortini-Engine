"""Editor UI Panels initialization."""

__all__ = []
