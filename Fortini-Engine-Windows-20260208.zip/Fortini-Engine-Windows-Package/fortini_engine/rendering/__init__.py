"""Rendering module initialization."""

from fortini_engine.rendering.opengl_renderer import OpenGLRenderer, Shader

__all__ = ["OpenGLRenderer", "Shader"]
