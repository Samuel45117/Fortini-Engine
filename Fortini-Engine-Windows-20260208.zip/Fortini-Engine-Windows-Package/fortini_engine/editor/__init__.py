"""Editor module initialization."""

from fortini_engine.editor.main import FortiniEditor

__all__ = ["FortiniEditor"]
